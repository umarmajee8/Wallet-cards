# CardWallet (patched)

This repo contains the patched source for the CardWallet app.

## Changes made
1. Removed the "Make your own pouch" custom color-picker feature (both the header menu entry and the Settings-screen row).
2. Added two new fixed pouch presets, selectable from Settings -> **Pouch style**:
   - **Frosted** (original default)
   - **Steel** - dark slate/blue-grey look
   - **Emerald** - dark green look

## Structure
- `app/` - the web bundle that runs inside the Android WebView (Capacitor-based hybrid app): `index.html`, the compiled/minified `index.js`, `index.css`, and icons.
- `android/AndroidManifest.xml` - the app's Android manifest.
- `patches/` - the exact Python scripts used to apply the changes above to the minified `index.js`, in order (patch1 -> patch4).
- `CardWallet_no_pouch.apk` - the final signed, installable APK with all changes applied.

## Build notes
The app was decompiled with `apktool`, patched with the scripts in `patches/`, rebuilt with `apktool b`, then signed with `uber-apk-signer` using a self-generated debug keystore (not the original developer's signing key - uninstall any previous install before installing this build).
